from setuptools import setup

setup(
    name="fojdpmdkkbloxghurhby",
    version="1.0.0",
    description="A simple example package",
)
